@echo off
echo Use gradlew on Linux/macOS or build with the included GitHub Actions workflow.
exit /b 1
